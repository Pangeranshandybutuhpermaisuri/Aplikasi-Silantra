// Ubah nilai ini ke URL publik backend PHP Anda, contoh: https://domain-anda.com/api/
window.SILANTRA_API_URL = window.SILANTRA_API_URL || "https://contoh-domain.com/api/";
